package tech.ada.monitoria.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Aluno {

	public static List<Map<String,Object>> listaAlunos = new ArrayList<>();
	
}
