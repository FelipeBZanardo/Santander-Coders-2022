package tech.ada.monitoria;

import tech.ada.monitoria.controller.AlunoController;

public class Main {

	public static void main(String[] args) {
		AlunoController controller = new AlunoController();
		controller.menu();
	}

}
